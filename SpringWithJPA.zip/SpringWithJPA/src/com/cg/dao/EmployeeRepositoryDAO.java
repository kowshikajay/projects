package com.cg.dao;

import java.util.List;

import com.cg.entities.Employee;

public interface EmployeeRepositoryDAO {

	
	public abstract Employee save(Employee employee);
	public abstract List<Employee> loadAll();
	
	
	
	
}
