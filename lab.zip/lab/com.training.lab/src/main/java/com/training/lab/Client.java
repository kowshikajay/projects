package com.training.lab;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext factory = new ClassPathXmlApplicationContext(
				"user.xml");
		Employee user =  (Employee) factory.getBean("currencyConverter");
		System.out.println("Employee details------------------");
		System.out.println("Employee id: "+user.getId());
		System.out.println("Employee name: "+user.getName());
		System.out.println("Employee age: "+user.getAge());
		System.out.println("Employee salary: "+user.getSalary());
		System.out.println("Employee Business unit: "+user.getBusinessunit());
	}

}
