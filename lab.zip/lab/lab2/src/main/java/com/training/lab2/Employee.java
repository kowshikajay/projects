package com.training.lab2;

public class Employee {

	private int id;
	private String name;
	private int age;
	private Sbu businessUnit;
	private double salary;

	
	public Employee(int id, String name, int age, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.salary = salary;
	}

	

	public void setBusinessUnit(Sbu businessUnit) {
		this.businessUnit = businessUnit;
	}

	public Sbu getSbuDetails() {
		return businessUnit;
	}



	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", age=" + age
				+ ", salary=" + salary +",\n SBU Details=" + businessUnit + " ]";
	}

	

}
