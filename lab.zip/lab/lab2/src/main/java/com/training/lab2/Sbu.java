package com.training.lab2;

public class Sbu {
	private int sbuCode;
	private String sbuName;
	private String subHead;

	

	public int getSbuCode() {
		return sbuCode;
	}

	public void setSbuCode(int sbuCode) {
		this.sbuCode = sbuCode;
	}

	public String getSbuName() {
		return sbuName;
	}

	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}

	public String getSubHead() {
		return subHead;
	}

	public void setSubHead(String subHead) {
		this.subHead = subHead;
	}

	@Override
	public String toString() {
		return "Sbu Details= SBU [sbuCode=" + sbuCode + ", sbuName=" + sbuName
				+ ", subHead=" + subHead + "]";
	}

}
