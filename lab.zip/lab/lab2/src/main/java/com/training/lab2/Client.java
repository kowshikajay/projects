package com.training.lab2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext factory = new ClassPathXmlApplicationContext("user.xml");
		Employee emp = (Employee) factory.getBean("currencyList");
		System.out.println(emp);

	}

}
