package com.cg.lab.spring;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext factory=new ClassPathXmlApplicationContext("employee.xml");
		SBU sbu=(SBU) factory.getBean("sbu");
		System.out.println(sbu);
		
		
	}

}
