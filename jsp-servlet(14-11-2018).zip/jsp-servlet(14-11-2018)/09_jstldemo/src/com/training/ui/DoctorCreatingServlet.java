package com.training.ui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.trainig.entity.Doctor;

/**
 * Servlet implementation class DoctorCreatingServlet
 */
@WebServlet("/DoctorCreatingServlet")
public class DoctorCreatingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Doctor doctor=new Doctor();
		Doctor doctor1=new Doctor();
		Doctor doctor2=new Doctor();
		Doctor doctor3=new Doctor();
		Doctor doctor4=new Doctor();
		doctor.setId(101);
		doctor.setName("kaushik");
		doctor.setQualification("Doctor");
		doctor.setGender("male");
		doctor.setFee(5000.00);
		doctor.setExperience(12);
		doctor1.setId(102);
		doctor1.setName("ajay");
		doctor1.setQualification("Doctor");
		doctor1.setGender("male");
		doctor1.setFee(3000.00);
		doctor1.setExperience(2);
		doctor2.setId(103);
		doctor2.setName("suriya");
		doctor2.setQualification("Doctor");
		doctor2.setGender("male");
		doctor2.setFee(32000.00);
		doctor2.setExperience(12);
		doctor3.setId(104);
		doctor3.setName("vikram");
		doctor3.setQualification("Doctor");
		doctor3.setGender("male");
		doctor3.setFee(12200.00);
		doctor3.setExperience(22);
		doctor4.setId(105);
		doctor4.setName("kamal");
		doctor4.setQualification("Doctor");
		doctor4.setGender("male");
		doctor4.setFee(78760.00);
		doctor4.setExperience(42);
		//request.setAttribute("DOC", doctor);
		List<Doctor> doctors=new ArrayList<Doctor>();
		doctors.add(doctor);
		doctors.add(doctor1);
		doctors.add(doctor2);
		doctors.add(doctor3);
		doctors.add(doctor4);
		request.setAttribute("DOCTORS", doctors);
		
		RequestDispatcher dispatcher=request.getRequestDispatcher("Display4.jsp");
		dispatcher.forward(request, response);
	}

}
