package com.training.ui;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Studentservlet
 */
@WebServlet(
		urlPatterns = { "/Studentservlet" }, 
		initParams = { 
				@WebInitParam(name = "i_rollno", value = "105"), 
				@WebInitParam(name = "i_name", value = "kowshik"), 
				@WebInitParam(name = "i_age", value = "22")
		})
public class Studentservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
private int rollno;
private String name;
private int age;
@Override
public void init() throws ServletException {
	ServletConfig config=getServletConfig();
	String strroll=config.getInitParameter("i_rollno");
	String strname=config.getInitParameter("i_name");
	String strage=config.getInitParameter("i_age");
	this.rollno=Integer.parseInt(strroll);
	this.name=strname;
	this.age=Integer.parseInt(strage);
	
}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	PrintWriter out=response.getWriter();
	out.println(rollno+"<br>");
	out.println(name+"<br>");
	
	out.println(age+"<br>");
	}

}
