package com.training.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.training.entity.Player;

@WebServlet("/Demo5")
public class Demo5 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		PrintWriter out = response.getWriter();
		Set<Player> players = new HashSet<>();
		Player p1 = new Player(101, "Gambhir", 50, 20000, 20, true);
		players.add(p1);
		Player p2 = new Player(102, "Dhoni", 22, 10000, 322, false);
		players.add(p2);
		Player p3 = new Player(103, "rohit", 33, 12000, 233, false);
		players.add(p3);
		Player p4 = new Player(104, "kohli", 44, 12121, 233, false);
		players.add(p4);
		Player p5 = new Player(105, "sehwag", 22, 32122, 211, false);
		players.add(p5);
		Player p6 = new Player(106, "russel", 44, 54545, 266, false);
		players.add(p6);
		Player p7 = new Player(107, "gayle", 12, 54543, 122, false);
		players.add(p7);
		Player p8 = new Player(108, "narine", 33, 12122, 122, false);
		players.add(p8);
		Player p9 = new Player(109, "sachin", 22, 34344, 112, false);
		players.add(p9);
		Player p10 = new Player(110, "ganguly", 11, 12213, 132, false);
		players.add(p10);
		Player p11 = new Player(111, "yuvaraj", 33, 65222, 177, false);
		players.add(p11);
		response.setContentType("text/html");
		out.println("<head>");
		out.println("<link href='Assign.css' rel='stylesheet'>");
		out.println("</head>");
		out.println("<table>");
		out.println("<tr>");
		out.println("<tr><th>Id</th><th>Playername</th><th>No.of matches</th><th>Total runs scored</th><th>No.of wickets taken</th><th>Captian(T/F)</th><th>Batting rating</th><th>Bowling rating</th></tr>");

		for (Player player : players) {
			out.println("<tr>");
			/*
			 * out.println("<td>" + player.getPlayerId() +
			 * player.getPlayerName() + player.getNoOfMatches() +
			 * player.getTotalRunsScored() + player.getNoOfWickets() +
			 * player.isCaptian() + "</td>");
			 */
			out.println("<td>" + player.getPlayerId() + "</td>");
			out.println("<td>" + player.getPlayerName() + "</td>");
			out.println("<td>" + player.getNoOfMatches() + "</td>");
			out.println("<td>" + player.getTotalRunsScored() + "</td>");
			out.println("<td>" + player.getNoOfWickets() + "</td>");
			out.println("<td>" + player.isCaptian() + "</td>");
			out.println("<td>" + player.getBattingRating() + "</td>");
			out.println("<td>" + player.getBowlingRating() + "</td>");
			out.println("</tr>");

		}
		out.println("</table>");

	}

}
