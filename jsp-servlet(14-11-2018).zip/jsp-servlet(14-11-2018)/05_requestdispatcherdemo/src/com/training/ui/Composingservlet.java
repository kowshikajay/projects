package com.training.ui;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Composingservlet
 */
@WebServlet("/Composingservlet")
public class Composingservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher dispatcher=null;
		RequestDispatcher dispatcher1=null;
		RequestDispatcher dispatcher2=null;
	dispatcher=request.getRequestDispatcher("Header.html");
	dispatcher1=request.getRequestDispatcher("Main.html");
	dispatcher2=request.getRequestDispatcher("Footer.html");
	dispatcher.include(request, response);
	dispatcher1.include(request, response);
	dispatcher2.include(request, response);
	}

}
