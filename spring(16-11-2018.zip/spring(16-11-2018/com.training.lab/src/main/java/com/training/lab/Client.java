package com.training.lab;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext factory = new ClassPathXmlApplicationContext(
				"user.xml");
		Employee user =  (Employee) factory.getBean("currencyConverter");
		System.out.println(user.getId());
		System.out.println(user.getName());
		System.out.println(user.getAge());
		System.out.println(user.getSalary());
		System.out.println(user.getBusinessunit());
	}

}
