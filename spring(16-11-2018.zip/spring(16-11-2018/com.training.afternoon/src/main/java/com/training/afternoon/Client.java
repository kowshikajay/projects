package com.training.afternoon;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Client {

	public static void main(String[] args) {
		ApplicationContext ct=new AnnotationConfigApplicationContext(MyBookConfig.class);
		Book user =   (Book) ct.getBean("book");
		System.out.println("Hashcode is"+user.hashCode());
		System.out.println(user);
		
	}
}
