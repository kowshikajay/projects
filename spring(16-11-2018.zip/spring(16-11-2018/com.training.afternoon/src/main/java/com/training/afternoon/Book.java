package com.training.afternoon;

import javax.annotation.*;

public class Book {

	private String isbn;
	private String year;
	private Author author;

	public Author getAuthor() {
		return author;
	}

	public void setAuthor(Author author) {
		this.author = author;
	}

	public void setUp() {
		System.out.println("setup method");
	}

	public void cleanUp() {
		System.out.println("cleanup method");
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	@PostConstruct
	public void customInit() {
		System.out.println("Book custom init method");
	}

	@PreDestroy
	public void customDestroy() {
		System.out.println("custom destroy method");
	}

	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", year=" + year + ", author=" + author
				+ "]";
	}

	
}
