package com.training.afternoon;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyBookConfig {
@Bean
	public Author author() {

		return new Author("kaushik", "kovvur");

	}
@Bean(initMethod="setUp",destroyMethod="cleanUp")
	public Book book() {
	
		Book book = new Book();
		book.setIsbn("123abc");
		book.setYear("2000");
		book.setAuthor(author());
		System.out.println("configuration");
		return book;
	}

}
