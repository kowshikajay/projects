package com.international;

import java.util.Locale;

import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		ApplicationContext factory = new ClassPathXmlApplicationContext(
				"user.xml");
		MessageSource messageSource = (MessageSource) factory
				.getBean("messageSource");
		Locale locale = new Locale("en", "TG");
		Locale locale1 = new Locale("en", "US");
		String msg = messageSource.getMessage("welcome.message", null, locale);
		String msg1 = messageSource.getMessage("welcome.message", null, locale1);
		System.out.println(msg);
		System.out.println(msg1);
		
	}
}
