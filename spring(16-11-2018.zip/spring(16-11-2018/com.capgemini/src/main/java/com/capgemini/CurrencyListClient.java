package com.capgemini;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CurrencyListClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext factory = new ClassPathXmlApplicationContext(
				"currencylist.xml");
		CurrencyList curr = (CurrencyList) factory.getBean("currencyList");

		ArrayList<String> list = curr. getCurrList();
		System.out.println(list);
	}
}