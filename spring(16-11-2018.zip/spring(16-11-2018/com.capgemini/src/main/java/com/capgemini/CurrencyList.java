package com.capgemini;

import java.util.ArrayList;

public interface CurrencyList {

	public abstract ArrayList<String> getCurrList();
}
