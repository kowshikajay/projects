package com.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext factory = new ClassPathXmlApplicationContext(
				"user.xml");
		User user =  (User) factory
				.getBean("currencyConverter");
		System.out.println(user.getName());
		System.out.println(user.getPassword());
	}

}
