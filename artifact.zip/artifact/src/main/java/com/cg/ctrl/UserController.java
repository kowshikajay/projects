package com.cg.ctrl;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping(value="user")
public class UserController {
	
	
	@RequestMapping(value="showLogin")
	public String preparedLogin(Model model){
		System.out.println("In preparedLogin() method");
		model.addAttribute("login",new Login());
		return "login";
	}
	
	
	@RequestMapping(value="checkLogin")
	public String checkLogin(){
		
		return "loginSuccess";
	}
	
	
	@RequestMapping(value="showRegister")
	public String preparedRegister(Model model){
		System.out.println("In preparedRegister() method");
		model.addAttribute("register", new User());
		return "register";
	}
	@RequestMapping(value="checkregister")
public String checkRegister(User user,Model model)
{
		model.addAttribute("user", user);
	return "registrationsucess";
}

}
