package com.capgemini.client;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.text.html.HTMLDocument.HTMLReader.PreAction;

import com.mysql.jdbc.PreparedStatement;

public class Main {
	public static Connection createConnection() throws SQLException,
			ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		String dbURL = "jdbc:mysql://localhost:3306/demodb";
		String userName = "root";
		String password = "pass";

		Connection connection = DriverManager.getConnection(dbURL, userName,
				password);
		return connection;
	}

	public static void insertRecord() throws ClassNotFoundException,
			SQLException {
		Connection connection = createConnection();

		System.out.println("connected successfully");
		String sql = "insert into Customer values(?,?,?,?)";
		int inp_id = 0;
		String inp_name = "";
		String inp_city = "";
		double inp_amt = 0.0;
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter Id:");
		inp_id = scanner.nextInt();
		System.out.print("Enter Name:");
		inp_name = scanner.next();
		System.out.print("Enter City:");
		inp_city = scanner.next();
		System.out.println("Enter Outstanding Amount:");
		inp_amt = scanner.nextDouble();
		PreparedStatement statement=(PreparedStatement) connection.prepareStatement(sql);
		statement.setInt(1, inp_id);
		statement.setString(2, inp_name);
		statement.setString(3, inp_city);
		statement.setDouble(4, inp_amt);
		 statement.executeUpdate();
		System.out.println("inserted");
		statement.close();
		connection.close();
	}

	public static void updateRecord() throws ClassNotFoundException,
			SQLException {
		Connection connection = createConnection();
		Scanner scanner = new Scanner(System.in);
		System.out.println("connected successfully");
		String sql = "update Customer set c_amt=c_amt+? where c_id=?";
double up_amt;
int up_id;
System.out.println("Enter the amount to update");
up_amt=scanner.nextDouble();
System.out.println("Enter the id to where you want to update the amount:");
up_id=scanner.nextInt();
		PreparedStatement statement = (PreparedStatement) connection.prepareStatement(sql);
		statement.setDouble(1, up_amt);
		statement.setInt(2,up_id );
		
		  statement.executeUpdate();
		System.out.println("row updated");
		statement.close();
		connection.close();
	}

	public static void deleteRecord() throws ClassNotFoundException,
			SQLException {
		Connection connection = createConnection();

		System.out.println("connected successfully");
		String sql = "delete from Customer where c_id=?";
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the id you want to delete:");
		int del_id=scanner.nextInt();
		PreparedStatement statement = (PreparedStatement) connection.prepareStatement(sql);
		statement.setInt(1, del_id);
		statement.executeUpdate();
	//	System.out.println(statement);
		System.out.println("deleted");
		statement.close();
		connection.close();
	}

	public static void displayAllRecords() throws ClassNotFoundException,
			SQLException {
		Connection connection = createConnection();
		String sql = "select * from Customer";
		Statement statement = connection.createStatement();
		ResultSet rs = statement.executeQuery(sql);
		while (rs.next()) {
			System.out.print(rs.getInt(1) + "\t");
			System.out.print(rs.getString(2) + "\t");
			System.out.print(rs.getString(3) + "\t");
			System.out.println(rs.getDouble(4) + "\t");

		}
		rs.close();
		statement.close();
		connection.close();
	}

	public static void displayOneRecord(int id) throws ClassNotFoundException,
			SQLException {
		Connection connection = createConnection();
		String sql = "select * from Customer where c_id=?" ;
		int dis_id;
		//Scanner scanner=System.in();
		System.out.println("enter the id to display");
	//	dis_id=scanner.nextInt();
		PreparedStatement statement = (PreparedStatement) connection.prepareStatement(sql);
		statement.setInt(1, id);
		ResultSet rs = statement.executeQuery();
		if (rs.next()) {
			System.out.print(rs.getInt(1) + "\t");
			System.out.print(rs.getString(2) + "\t");
			System.out.print(rs.getString(3) + "\t");
			System.out.println(rs.getDouble(4) + "\t");

		}
		rs.close();
		statement.close();
		connection.close();
	}

	public static void main(String[] args) throws ClassNotFoundException,
			SQLException {
		 //deleteRecord();
		//displayAllRecords();
		// displayOneRecord(3);
		//insertRecord();
		//deleteRecord();
		updateRecord();
		
	/*Scanner scanner=new Scanner(System.in);
	System.out.println("Enter the id to display:");
	int id=scanner.nextInt();
	displayOneRecord(id);*/
	}
}
