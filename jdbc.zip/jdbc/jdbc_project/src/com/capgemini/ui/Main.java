package com.capgemini.ui;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.business.Customer;
import com.capgemini.db.CustomerDAO;
import com.capgemini.db.CustomerDAOImp;

public class Main {

	public static void main(String[] args) throws ClassNotFoundException,
			SQLException {
while(true){
		System.out.println("Customer Application");
		System.out
				.println("---------------------------------------------------");
		System.out.println("1.Add new customer");
		System.out.println("2.update customer");
		System.out.println("3.Display all customers");
		System.out.println("4.delete customer");
		System.out.println("5.exit");
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter choice");
		int choice = scanner.nextInt();
		switch (choice) {

		case 1:
			add();
			break;
		case 2:
			update();
			break;
		case 3:
			display();
			break;
		case 4:
			remove();
			break;
		case 5:
			System.out.println("Thank you");
			System.exit(0);
			break;

		}
	}
	}
	public static void add() throws ClassNotFoundException, SQLException {
		int id = 0;
		String name = null;
		String city = null;
		double amt = 0.0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter id");
		id = scanner.nextInt();
		System.out.println("enter name");
		name = scanner.next();
		System.out.println("enter city");
		city = scanner.next();
		System.out.println("enter amount");
		amt = scanner.nextDouble();
		Customer customer = new Customer();
		customer.setId(id);
		customer.setName(name);
		customer.setCity(city);
		customer.setOutStandingBalance(amt);
		CustomerDAO dao = new CustomerDAOImp();
		boolean result = dao.addCustomer(customer);
		if (result == true) {
			System.out.println("added successfully");
		} else {
			System.out.println("Adding failed");
		}
	}

	public static void update() throws ClassNotFoundException, SQLException {
		int id = 0;
		String name = null;
		String city = null;
		double amt = 0.0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter id to update");
		id = scanner.nextInt();
		System.out.println("enter name");
		name = scanner.next();
		System.out.println("enter city");
		city = scanner.next();
		System.out.println("enter amount");
		amt = scanner.nextDouble();
		Customer customer = new Customer();
		customer.setId(id);
		customer.setName(name);
		customer.setCity(city);
		customer.setOutStandingBalance(amt);
		CustomerDAO dao = new CustomerDAOImp();
		boolean result = dao.updateCustomer(customer);
		if (result == true) {
			System.out.println("updated successfully");
		} else {
			System.out.println("updation failed");
		}

	}

	public static void display() throws ClassNotFoundException, SQLException {
		CustomerDAO dao = new CustomerDAOImp();
		List<Customer> list = dao.getAllCustomers();
		for (Customer customer : list) {
			System.out.print(customer.getId() + "\t");
			System.out.print(customer.getName() + "\t");
			System.out.print(customer.getCity() + "\t");
			System.out.println(customer.getOutStandingBalance());
			// System.out.println(customer);
		}
	}

	public static void remove() throws ClassNotFoundException, SQLException {
		int inp_id = 0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter Id to remove");
		inp_id = scanner.nextInt();
		CustomerDAO dao = new CustomerDAOImp();
		boolean result = dao.removeCustomer(inp_id);
		if (result == true) {
			System.out.println("record deleted successfully");
		} else {
			System.out.println("not deleted");
		}
	}
}
