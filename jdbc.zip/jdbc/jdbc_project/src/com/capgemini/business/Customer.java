package com.capgemini.business;

public class Customer {

	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		if (id < 0) {
			throw new RuntimeException("Invalid Id");
			
		} else {
			this.id = id;
		}
	}

	public String getName() {

		return name.toUpperCase();
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public double getOutStandingBalance() {
		return outStandingBalance;
	}

	public void setOutStandingBalance(double outStandingBalance) {
		this.outStandingBalance = outStandingBalance;
	}

	private String name;
	private String city;
	private double outStandingBalance;

	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", city=" + city
				+ ", outStandingBalance=" + outStandingBalance + "]";
	}

	public String getCustomerRating() {
		if (this.outStandingBalance < 5000) {
			return "good";
		} else {
			return "normal";
		}
	}
}
