package com.capgemini.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.business.Customer;
import com.mysql.jdbc.PreparedStatement;

public class CustomerDAOImp implements CustomerDAO {

	@Override
	public boolean addCustomer(Customer customer)
			throws ClassNotFoundException, SQLException {
		Connection connection = ConnectionManager.createConnection();
		String sql = "insert into Customer values(?,?,?,?)";
		PreparedStatement statement = (PreparedStatement) connection
				.prepareStatement(sql);
		statement.setInt(1, customer.getId());
		statement.setString(2, customer.getName());
		statement.setString(3, customer.getCity());
		statement.setDouble(4, customer.getOutStandingBalance());
		int r = statement.executeUpdate();
		if (r > 0) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean removeCustomer(int customerId)
			throws ClassNotFoundException, SQLException {
		Connection connection = ConnectionManager.createConnection();
		String sql = "delete from Customer where c_id=?";
		PreparedStatement statement = (PreparedStatement) connection
				.prepareStatement(sql);
		statement.setInt(1, customerId);
		int r = statement.executeUpdate();
		return true;
	}

	@Override
	public boolean updateCustomer(Customer customer) throws ClassNotFoundException, SQLException {
		Connection connection = ConnectionManager.createConnection();
		String sql = "update Customer set c_name=?,c_city=?,c_amt=? where c_id=?";
		PreparedStatement statement = (PreparedStatement) connection
				.prepareStatement(sql);
		statement.setInt(4, customer.getId());
		statement.setString(1, customer.getName());
		statement.setString(2, customer.getCity());
		statement.setDouble(3, customer.getOutStandingBalance());
		int r = statement.executeUpdate();
		if (r > 0) {
			return true;
		} else {
			return false;
		}
		
	}
	@Override
	public Customer findCustomer(int customerId) {

		return null;
	}

	@Override
	public List<Customer> getAllCustomers() throws ClassNotFoundException,
			SQLException {
		List<Customer> customers = new ArrayList<Customer>();
		Connection connection = ConnectionManager.createConnection();
		String sql = "select * from Customer";
		PreparedStatement statement = (PreparedStatement) connection
				.prepareStatement(sql);
		ResultSet rs = statement.executeQuery();
		while (rs.next()) {
			int id = rs.getInt(1);
			String name = rs.getString(2);
			String city = rs.getString(3);
			Double amt = rs.getDouble(4);
			Customer customer = new Customer();
			customer.setId(id);
			customer.setName(name);
			customer.setCity(city);
			customer.setOutStandingBalance(amt);
			customers.add(customer);
		}
		statement.close();
		connection.close();
		return customers;

	}

}
