package com.training.client;


/**
 * 
 * @author myajay
 *
 */
public class Test4 {
	/**
	 * 
	 * @param n number to be computed
	 * @return returns square of n
	 */
int square(int n){
	return n*n;
}
}
