package com.training.client;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(value =RetentionPolicy.RUNTIME)
public @interface table {
	String name();

}
