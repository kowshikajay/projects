package com.training.client;

public @interface entity {
	
}
