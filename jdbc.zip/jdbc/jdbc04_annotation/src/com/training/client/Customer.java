package com.training.client;
@table(name = "Customer")
@entity
public class Customer {
@Id
	int id;


@Column(name = "c_name", notNull = true, size = 25)
String name;
@Column(name = "c_city", notNull = true, size = 20)
String city;
double outStandingAmt;
}
