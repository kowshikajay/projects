package com.capg.paymentwallet.service;

import java.math.BigInteger;

import com.capg.paymentwallet.bean.Account;

import com.capg.paymentwallet.bean.CustomerBean;




import com.capg.paymentwallet.dao.DaoImp;

import com.capg.paymentwallet.dao.IDaoInterface;
import com.capg.paymentwallet.exception.CustomerException;
import com.capg.paymentwallet.exception.CustomerExceptionMessage;

public class CustomerServiceImp implements ICustomerService {
	IDaoInterface dao = new DaoImp();

	
	public boolean validate(CustomerBean customer) throws CustomerException {
		boolean isValid = true;
		if (!(customer.getFirstName().matches("[a-z A-Z]"))) {
			isValid = false;
			throw new CustomerException(CustomerExceptionMessage.ERROR1);
		}
		if ((customer.getFirstName() == null)) {
			isValid = false;
			throw new CustomerException(CustomerExceptionMessage.ERROR1);
		}
		if (!(customer.getLastName().matches("[a-z A-Z]"))) {
			isValid = false;
			throw new CustomerException(CustomerExceptionMessage.ERROR2);
		}
		if (customer.getLastName() == null) {
			isValid = false;
			throw new CustomerException(CustomerExceptionMessage.ERROR2);

		}
		if (!(customer.getPhoneNo().matches("[6-9][0-9]{9}"))) {

			isValid = false;
			throw new CustomerException(CustomerExceptionMessage.ERROR5);
		}
		if (customer.getPhoneNo() == null) {
			isValid = false;
			throw new CustomerException(CustomerExceptionMessage.ERROR5);
		}
		if (!(customer.getEmailId()
				.matches("[a-zA-Z][a-zA-z0-9-.]*@[a-zA-Z0-9]+([.][a-zA-Z)]+)+"))) {

			isValid = false;
			throw new CustomerException(CustomerExceptionMessage.ERROR3);
		}
		if (customer.getEmailId() == null) {
			isValid = false;
			throw new CustomerException(CustomerExceptionMessage.ERROR3);
		}
		if (!(customer.getPanNum().matches("[A-Z][0-9]{10}"))) {

			isValid = false;
			throw new CustomerException(CustomerExceptionMessage.ERROR4);
		}
		if ((customer.getPanNum() == null)) {
			isValid = false;
			throw new CustomerException(CustomerExceptionMessage.ERROR4);
		}
		if ((customer.getAddress() == null)
				|| !(customer.getAddress().matches("[A-Z][0-9]{10,50}"))) {
			isValid = false;
			throw new CustomerException(CustomerExceptionMessage.ERROR7);
		}
		if (customer.getAddress() == null) {
			isValid = false;
			throw new CustomerException(CustomerExceptionMessage.ERROR7);
		}
		

		return isValid;
	}

	

	
	@Override
	public boolean createAccount(Account accountBean) {
		
		boolean result=dao.createAccount(accountBean);
		return result;
		
		
	}

	@Override
	public Account findAccount(int accId) {
		Account bean=dao.findAccount(accId);
		return bean;
		
	}

	@Override
	public boolean deposit(Account accountBean, double depositAmt) {
		accountBean.setBalance(accountBean.getBalance() + depositAmt);
		
		boolean result = dao.updateAccount(accountBean);
		return result;
	}




	@Override
	public boolean withdraw(Account accountBean, double withdrawAmt) {
		accountBean.setBalance(accountBean.getBalance()-withdrawAmt);
		
		boolean result=dao.updateAccount(accountBean);
		return result;	
	}



	@Override
	public boolean fundTransfer(Account transferingAccountBean,
			Account beneficiaryAccountBean, double transferAmount)
			 {

		transferingAccountBean.setBalance(transferingAccountBean.getBalance()
				- transferAmount);
		beneficiaryAccountBean.setBalance(beneficiaryAccountBean.getBalance()
				+ transferAmount);

		
		boolean result1 = dao.updateAccount(transferingAccountBean);
		boolean result2 = dao.updateAccount(beneficiaryAccountBean);
		return result1 && result2;
	}
	



	
	

}
