package com.capg.paymentwallet.dao;

import java.math.BigInteger;

import com.capg.paymentwallet.bean.Account;
import com.capg.paymentwallet.bean.CustomerBean;
import com.capg.paymentwallet.exception.CustomerException;

public interface IDaoInterface {

	
	
	public boolean createAccount(Account accountBean);
	public Account findAccount(int accId);

	public boolean updateAccount(Account accountBean);

}
