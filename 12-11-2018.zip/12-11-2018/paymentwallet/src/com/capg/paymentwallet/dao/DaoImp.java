package com.capg.paymentwallet.dao;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

import javax.persistence.EntityManager;

import com.capg.paymentwallet.bean.Account;
import com.capg.paymentwallet.bean.CustomerBean;
import com.capg.paymentwallet.bean.Transfer;
import com.capg.paymentwallet.exception.CustomerException;

public class DaoImp implements IDaoInterface {
	Transfer transfer = new Transfer();
	CustomerBean customerbean = new CustomerBean();
	ArrayList<CustomerBean> list = new ArrayList<CustomerBean>();
	static ArrayList<String> printList = new ArrayList<String>();
	EntityManager em;

	
	

	
	@Override
	public boolean createAccount(Account accountBean) {
try{
			
			this.em=JPAManager.createEntityManager();
			em.getTransaction().begin();
			
			em.persist(accountBean);
			
			em.getTransaction().commit();
			JPAManager.closeResources(em);
			
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		
	}

	@Override
	public Account findAccount(int accId) {
		try{
			em=JPAManager.createEntityManager();
			Account accountBean2=em.find(Account.class,accId);
			JPAManager.closeResources(em);
			return accountBean2;
			
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}

	

	@Override
	public boolean updateAccount(Account accountBean) {
		try{
			this.em=JPAManager.createEntityManager();
			em.getTransaction().begin();
			
			em.merge(accountBean);
			
			em.getTransaction().commit();
			JPAManager.closeResources(em);
			return true;
		}catch(Exception e){
			return false;
		}
	
		
	}

		
	}


