package com.capg.intro;

public interface ExchangeService {
public double getExchangeRate();
}
