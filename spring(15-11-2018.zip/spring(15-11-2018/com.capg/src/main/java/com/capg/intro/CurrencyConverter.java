package com.capg.intro;

public interface CurrencyConverter {
	public double dollarsToRupees(double dollars);

}
