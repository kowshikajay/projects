package com.cg.ctrl;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value = "user")
public class UserController {
	ArrayList<String> cityList;
	ArrayList<String> skillList;

	@RequestMapping(value = "showLogin")
	public String preparedLogin(Model model) {
		System.out.println("In preparedLogin() method");
		model.addAttribute("login", new Login());
		return "login";
	}

	@RequestMapping(value = "checkLogin")
	public String checkLogin() {

		return "loginSuccess";
	}

	@RequestMapping(value = "/showRegister")
	public String preparedRegister(Model model) {
		cityList = new ArrayList<String>();
		cityList.add("hyderabad");
		cityList.add("kovvur");
		cityList.add("bangalore");
		skillList = new ArrayList<String>();
		skillList.add("Java");
		skillList.add("Spring");
		skillList.add("Hibernate");
		model.addAttribute("cityList", cityList);
		model.addAttribute("skillList", skillList);

		System.out.println("In preparedRegister() method");
		model.addAttribute("register", new User());
		return "register";
	}

	@RequestMapping(value = "/checkregister")
	public String checkRegister(@ModelAttribute("user") @Valid User user,
			BindingResult result, Model model) {

		if (result.hasErrors()) {
			System.out.println("Error");
			model.addAttribute("cityList", cityList);
			model.addAttribute("skillList", skillList);
			return "register";
		} else {
			model.addAttribute("user", user);

			return "registrationsucess";
		}
	}
}
