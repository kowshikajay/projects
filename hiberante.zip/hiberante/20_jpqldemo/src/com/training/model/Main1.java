package com.training.model;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String jpql = "select p from Person p where p.gender='M'";

		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		Query query = em.createQuery(jpql);
		List<Person> list = query.getResultList();
		for (Person p : list) {
			/*System.out.print(p.getPersonId());
			System.out.print(p.getName());
			System.out.print(p.getAge());
			System.out.println(p.getGender());*/
			System.out.println(p);
		}

		em.close();
		factory.close();

	}

}
