package com.capg.assignment;

import java.util.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name = "bank_cust25")
public class Customer {
	private String name;
	@Temporal(TemporalType.DATE)	//required for Date and Calendar Types
	@Column(name = "order_date")
	private Date date;
	@ManyToMany(fetch=FetchType.LAZY,mappedBy="customerList")
	List<Bank> bankList=new ArrayList<Bank>();
	public void addBank(Bank bank){
		this.bankList.add(bank);
	}
	@Id
	@GeneratedValue
private int id;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}
public List<Bank> getBankList() {
	return bankList;
}
public void setBankList(List<Bank> bankList) {
	this.bankList = bankList;
}

	
}
