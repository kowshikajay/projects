package com.capg.assignment;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "bank25")
public class Bank {
	private String name;
	private String headOfficeLocation;
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "bank_customer", joinColumns = { @JoinColumn(name = "bank_id") }, inverseJoinColumns = { @JoinColumn(name = "id") })
	List<Customer> customerList = new ArrayList<Customer>();

	public void addCustomer(Customer c) {
this.customerList.add(c);

	}

	@Id
	@GeneratedValue
	private int bank_id;

	

	public int getBank_id() {
		return bank_id;
	}

	public void setBank_id(int bank_id) {
		this.bank_id = bank_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHeadOfficeLocation() {
		return headOfficeLocation;
	}

	public void setHeadOfficeLocation(String headOfficeLocation) {
		this.headOfficeLocation = headOfficeLocation;
	}

	public List<Customer> getCustomerList() {
		return customerList;
	}

	public void setCustomerList(List<Customer> customerList) {
		this.customerList = customerList;
	}

}
