package com.capg.assignment;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Bank bank1 = new Bank();
		bank1.setName("ICICI");
		bank1.setHeadOfficeLocation("PUNE");
		
		Customer customer1 = new Customer();

		customer1.setName("kaushikAJAY");
		customer1.setDate(new Date());
		bank1.addCustomer(customer1);
		customer1.addBank(bank1);
		em.persist(bank1);
		em.persist(customer1);
		Bank bank2 = new Bank();
		bank2.setName("ICICI");

		bank2.setHeadOfficeLocation("chennai");
		Bank bank3 = new Bank();
		bank3.setName("AXIS");

		bank3.setHeadOfficeLocation("pune");
		Bank bank4 = new Bank();
		bank4.setName("ANDB");

		bank4.setHeadOfficeLocation("bengaluru");
		Bank bank5 = new Bank();
		bank5.setName("SBI");

		bank5.setHeadOfficeLocation("mumbai");
		

		Customer customer2 = new Customer();

		customer2.setName("ajay");
		customer2.setDate(new Date());
		Customer customer3 = new Customer();

		customer3.setName("suriya");
		customer3.setDate(new Date());
		Customer customer4 = new Customer();

		customer4.setName("vikram");
		customer4.setDate(new Date());
		Customer customer5 = new Customer();

		customer5.setName("kamal");
		customer5.setDate(new Date());
		Customer customer6 = new Customer();

		customer6.setName("hasan");
		customer6.setDate(new Date());
		Customer customer7 = new Customer();

		customer7.setName("naveen");
		customer7.setDate(new Date());
		Customer customer8 = new Customer();

		customer8.setName("nani");
		customer8.setDate(new Date());
		Customer customer9 = new Customer();

		customer9.setName("komal");
		customer9.setDate(new Date());
		Customer customer10 = new Customer();

		customer10.setName("ram");
		customer10.setDate(new Date());
		bank1.addCustomer(customer1);
		bank1.addCustomer(customer2);

		bank1.addCustomer(customer3);
		bank2.addCustomer(customer9);
		bank2.addCustomer(customer8);
		bank3.addCustomer(customer5);
		bank3.addCustomer(customer4);
		bank4.addCustomer(customer3);
		bank4.addCustomer(customer10);
		bank5.addCustomer(customer9);
		bank5.addCustomer(customer7);
		customer1.addBank(bank3);
		customer1.addBank(bank2);
		customer10.addBank(bank4);
		customer10.addBank(bank4);
		
		em.persist(bank2);
		em.persist(bank3);
		em.persist(bank4);
		em.persist(bank5);
		em.persist(customer10);
		em.persist(customer1);
	em.close();
	factory.close();
	}
}
