package com.training.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();

		Loan loan = new Loan();
		loan.setCustomerName("kaushik");
		loan.setLoan_id(2001);
		loan.setLoanAmount(50000.00);

		Repayment repayment1 = new Repayment();
		repayment1.setInstallementNumber(101);
		repayment1.setRepayAmount(2000);
		repayment1.setRepaymentId(1);
		Repayment repayment2 = new Repayment();
		repayment2.setInstallementNumber(102);
		repayment2.setRepayAmount(3000);
		repayment2.setRepaymentId(3);

		loan.addRepayment(repayment1);
		loan.addRepayment(repayment2);
		em.persist(loan);
		System.out.println("Added two repayment details");
		em.getTransaction().commit();
		em.close();
		factory.close();
	}

}
