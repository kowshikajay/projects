package com.training.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="loan")
public class Loan {
	@Override
	public String toString() {
		return "Loan [loan_id=" + loan_id + ", customerName=" + customerName
				+ ", loanAmount=" + loanAmount + ", list=" + list + "]";
	}
@Id
	private int loan_id;
	private String customerName;
	private double loanAmount;
	@OneToMany(cascade=CascadeType.ALL)
	List<Repayment> list = new ArrayList<Repayment>();

	public int getLoan_id() {
		return loan_id;
	}

	public void setLoan_id(int loan_id) {
		this.loan_id = loan_id;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}

	public List<Repayment> getList() {
		return list;
	}

	public void setList(List<Repayment> list) {
		this.list = list;
	}

	public void addRepayment(Repayment rp) {
		this.list.add(rp);
	}
}
