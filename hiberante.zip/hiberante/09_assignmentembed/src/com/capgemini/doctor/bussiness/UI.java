package com.capgemini.doctor.bussiness;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.doctor.bean.Doctor;
import com.capgemini.doctor.bean.Qualification;

public class UI {
	public static void main(String[] args) {
		Doctor doctor=new Doctor();
	
		doctor.setName("ajay");
		doctor.setAmount(15000.00);
		Qualification qualify=new Qualification();
		qualify.setExperience(3);
		qualify.setQualification("M.B.A");
		doctor.setQualification(qualify);
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(doctor);
		
		em.getTransaction().commit();
		em.close();
		emf.close();
	}
}
