package com.cg.jpastart.entities;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		List<Student> empList = null;
		em.getTransaction().begin();
		Student student = new Student();
		Query q = em.createQuery("from Student");
		empList = q.getResultList();
		// student.setName("");
		for (Student student2 : empList) {
			student2.setName(student2.getName().toUpperCase());
			em.merge(student2);
		}
	//em.persist(student); // insert
		em.getTransaction().commit(); // persist has to be given within a
										// transaction

		System.out.println("removed one student to database.");
		em.close();
		factory.close();
	}

}
