package com.cg.jpastart.entities;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Address add=em.find(Address.class, 1);
		System.out.println(add.getAddressId()+" "+add.getCity()+" "+add.getState()+" "+add.getZipCode());
	Student student=new Student();
	
	
	student=em.find(Student.class,13);
	System.out.println(student.getName()+"  "+student.getAddress().getCity()+"	"+student.getStudentId());
	em.close();
	factory.close();
}


}
