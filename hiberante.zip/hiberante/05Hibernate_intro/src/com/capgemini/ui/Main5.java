package com.capgemini.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.business.Contact;

public class Main5 {

	public static void main(String[] args) {
	Contact contact=new Contact(101,"kaushik","9963144561");
	Contact contact1=new Contact(102,"ajay","9963144561");
	Contact contact2=new Contact(103,"vikram","9963144561");
	Contact contact3=new Contact(104,"suriya","9963144561");
	//Contact contact4=null;
	EntityManagerFactory emf = Persistence
			.createEntityManagerFactory("JPA-PU");
	EntityManager em = emf.createEntityManager();
	em.getTransaction().begin();
	em.persist(contact);
	em.persist(contact1);
	em.persist(contact2);
	em.persist(contact3);
	contact3.setPhoneNumber("7894561235");
	em.merge(contact3);
	em.getTransaction().commit();
	em.close();
	emf.close();
	}

}
