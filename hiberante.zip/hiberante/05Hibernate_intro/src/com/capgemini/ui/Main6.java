package com.capgemini.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.business.Contact;

public class Main6 {

	public static void main(String[] args) {
		
		Contact contact=new Contact(101,"kaushik","9963144561");
		Contact contact1=new Contact(102,"ajay","9963144561");
		Contact contact2=new Contact(103,"vikram","9963144561");
		Contact contact3=new Contact(104,"suriya","9963144561");
		Contact contact4=null;
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = emf.createEntityManager();// TODO Auto-generated method stub
contact4=em.find(Contact.class, 103);
contact4.setPhoneNumber("1234567890");

em.getTransaction().begin();
/*em.persist(contact);
em.persist(contact1);
em.persist(contact2);
em.persist(contact3);*/
contact3.setPhoneNumber("7894561235");
//em.merge(contact3);
em.merge(contact4);
em.persist(contact4);
em.getTransaction().commit();
System.out.println(contact4.equals(contact2));
em.close();
emf.close();
	}

}
